package com.javiernoriega.customdialogs;

/* Created by Javier Noriega on May 4 2021
   Custom Dialogs Comparison and Tutorial */

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declaring the buttons
    Button b1, b2, b3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Finding the view by its id so that we can use it
        b1 = findViewById(R.id.button_dialog1);
        b1.setBackgroundColor(Color.BLACK);
        b1.setOnClickListener(new View.OnClickListener() { // Call the click listener method
            @Override
            public void onClick(View v) {
                NormalPlainDialog(); // Call method to show Dialog
            }
        });


        b2 = findViewById(R.id.button_dialog2);
        b2.setBackgroundColor(Color.BLACK);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomDialog();
            }
        });


        b3 = findViewById(R.id.button_dialog3);
        b3.setBackgroundColor(Color.BLACK);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomizableButtons();
            }
        });
    }

    public void NormalPlainDialog(){

        /* SIMPLE DIALOG */

        // Step 1 - Declare the dialog builder
        AlertDialog.Builder simpleDialog = new AlertDialog.Builder(this);

        // Step 2 - Set title and message
        simpleDialog.setTitle("Simple Dialog Title");
        simpleDialog.setMessage("Simple Dialog Message\n\nThis is a simple dialog which is easy to make but limited in case you want to display more information");

        // Step 3 - Set the positive and negative buttons as well as their OnClickListeners
        simpleDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ShowYesToast();
            }
        });
        simpleDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ShowNoToast();
            }
        });

        // Step 4 - create and show
        simpleDialog.create().show();
    }

    public void CustomDialog(){

        /* CUSTOM DIALOG
           We can put as many views as we want */

        // Step 1 - Declare the dialog builder
        AlertDialog.Builder customDialog = new AlertDialog.Builder(this);

        // Just setting a title and message here...
        customDialog.setTitle("Custom Dialog Title");
        customDialog.setMessage("Custom Dialog Message");
        customDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //
            }
        });

        // Step 2 - Declare the layout
        LinearLayout linearLayout = new LinearLayout(this);
        // Also set the orientation for this linear layout
        linearLayout.setOrientation(LinearLayout.VERTICAL);

        // Step 3 - Create as many views as we want, to display them on the Dialog we need one more step...
        TextView textView = new TextView(this);
        textView.setText("  You can add TextViews");

        EditText editText = new EditText(this);
        editText.setInputType(InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE);
        editText.setHint("You can add EditTexts");

        Button button = new Button(this);
        button.setText("You can add buttons");
        button.setBackgroundColor(Color.BLACK);
        button.setTextColor(Color.WHITE);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DisplayTextInsideDialog(editText);
            }
        });

        ImageView imageView = new ImageView(this);
        imageView.setImageResource(R.drawable.image);

        // Step 4 - Add the views to the Dialog
        linearLayout.addView(textView);
        linearLayout.addView(editText);
        linearLayout.addView(button);
        linearLayout.addView(imageView);

        // Step 5 - a) Use setView from the layout to the dialog, b) Create new dialog, c) With that new dialog Create and Show

        // a)
        customDialog.setView(linearLayout);

        // b) c)
        AlertDialog dialog = customDialog.create();
        dialog.show();      // this last part you must do type it like this or else it will not work

    }

    public void CustomizableButtons(){

        /* DIALOG BUTTONS THAT DON'T CLOSE*/

        // Step 1 - Declare the Dialog Builder
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);

        // Just setting a title and message here...
        alertDialog.setTitle("This button won't make the Dialog Close");
        alertDialog.setMessage("You can use it if you want to close the dialog only when certain condition is met");

        // Step 2 - Create the button and on the listener part put "null", to make the dialog not close we are still missing one more step
        alertDialog.setPositiveButton("Click Me", null);

        // Step 3 - "Assign" our first "built" Dialog to a new Dialog without the Builder, then Create and Show
        AlertDialog dialog = alertDialog.create();
        dialog.show();

        // Step 4 - Get the button you used, then do whatever you want on the Listener
        Button button = dialog.getButton(AlertDialog.BUTTON_POSITIVE);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // We can put a Toast or nothing here
            }
        });

    }

    public void ShowYesToast(){
        Toast.makeText(this, "Yes Button Clicked", Toast.LENGTH_SHORT).show();
    }

    public void ShowNoToast(){
        Toast.makeText(this, "No Button Clicked", Toast.LENGTH_SHORT).show();
    }

    public void DisplayTextInsideDialog(EditText editText){
        Toast.makeText(this, editText.getText().toString(), Toast.LENGTH_SHORT).show();
    }
}